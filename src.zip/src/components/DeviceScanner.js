import React, { useState, useEffect } from 'react';
import {
  View,
  Text,
  StyleSheet,
  FlatList,
  TouchableOpacity,
  ActivityIndicator,
  Modal,
  Alert,
  ScrollView,
} from 'react-native';
import BluetoothService from '../services/BluetoothService';

const DeviceScanner = ({ onDeviceConnected }) => {
  const [devices, setDevices] = useState([]);
  const [scanning, setScanning] = useState(false);
  const [connecting, setConnecting] = useState(false);
  const [connectedDevice, setConnectedDevice] = useState(null);
  const [permissionsGranted, setPermissionsGranted] = useState(false);
  const [showDetails, setShowDetails] = useState(false);
  const [selectedDevice, setSelectedDevice] = useState(null);

  // Request permissions on component mount
  useEffect(() => {
    requestPermissions();
  }, []);

  const requestPermissions = async () => {
    const granted = await BluetoothService.requestBluetoothPermissions();
    setPermissionsGranted(granted);
    
    if (!granted) {
      Alert.alert(
        'Permission Required',
        'Bluetooth permissions are required to search for printers',
        [{ text: 'OK' }]
      );
    }
  };

  const startScanning = () => {
    if (!permissionsGranted) {
      Alert.alert('Permissions needed', 'Please grant Bluetooth permissions first');
      return;
    }

    setScanning(true);
    setDevices([]);
    
    // Start scanning with callback for new devices
    BluetoothService.startDeviceScan((deviceInfo) => {
      setDevices(prevDevices => {
        // Check if device already exists
        const exists = prevDevices.some(d => d.id === deviceInfo.id);
        if (!exists) {
          return [...prevDevices, deviceInfo];
        }
        return prevDevices;
      });
    });

    // Auto-stop UI state after 10 seconds (matches service timeout)
    setTimeout(() => {
      setScanning(false);
    }, 10000);
  };

  const stopScanning = () => {
    BluetoothService.stopDeviceScan();
    setScanning(false);
  };

  const connectToDevice = async (device) => {
    setConnecting(true);
    setSelectedDevice(device);
    
    const result = await BluetoothService.connectToDevice(device.id, (connectionResult) => {
      if (connectionResult.success) {
        setConnectedDevice(connectionResult.device);
        setConnecting(false);
        Alert.alert('Success', `Connected to ${device.name}`);
        
        // Notify parent component
        if (onDeviceConnected) {
          onDeviceConnected(connectionResult.device);
        }
      } else {
        setConnecting(false);
        Alert.alert('Connection Failed', connectionResult.error);
      }
    });

    // Fallback if callback doesn't fire
    if (result.success) {
      setConnectedDevice(result.device);
      setConnecting(false);
    }
  };

  const disconnectDevice = async () => {
    const result = await BluetoothService.disconnectDevice();
    if (result.success) {
      setConnectedDevice(null);
      Alert.alert('Disconnected', 'Device disconnected successfully');
    }
  };

  const renderDeviceItem = ({ item }) => (
    <TouchableOpacity
      style={styles.deviceItem}
      onPress={() => setSelectedDevice(item)}
      onLongPress={() => connectToDevice(item)}
    >
      <View style={styles.deviceInfo}>
        <Text style={styles.deviceName}>
          {item.name || 'Unknown Device'}
        </Text>
        <Text style={styles.deviceId}>ID: {item.id.substring(0, 8)}...</Text>
        <Text style={styles.deviceRssi}>Signal: {item.rssi} dBm</Text>
      </View>
      <TouchableOpacity
        style={[
          styles.connectButton,
          connectedDevice?.id === item.id && styles.connectedButton
        ]}
        onPress={() => 
          connectedDevice?.id === item.id 
            ? disconnectDevice() 
            : connectToDevice(item)
        }
        disabled={connecting}
      >
        <Text style={styles.connectButtonText}>
          {connectedDevice?.id === item.id ? 'Disconnect' : 'Connect'}
        </Text>
      </TouchableOpacity>
    </TouchableOpacity>
  );

  const DeviceDetailsModal = () => (
    <Modal
      visible={showDetails && selectedDevice !== null}
      animationType="slide"
      transparent={true}
    >
      <View style={styles.modalContainer}>
        <View style={styles.modalContent}>
          <Text style={styles.modalTitle}>Device Details</Text>
          
          {selectedDevice && (
            <ScrollView>
              <View style={styles.detailRow}>
                <Text style={styles.detailLabel}>Name:</Text>
                <Text style={styles.detailValue}>{selectedDevice.name || 'N/A'}</Text>
              </View>
              
              <View style={styles.detailRow}>
                <Text style={styles.detailLabel}>Local Name:</Text>
                <Text style={styles.detailValue}>{selectedDevice.localName || 'N/A'}</Text>
              </View>
              
              <View style={styles.detailRow}>
                <Text style={styles.detailLabel}>Device ID:</Text>
                <Text style={styles.detailValue}>{selectedDevice.id}</Text>
              </View>
              
              <View style={styles.detailRow}>
                <Text style={styles.detailLabel}>RSSI:</Text>
                <Text style={styles.detailValue}>{selectedDevice.rssi} dBm</Text>
              </View>
              
              <View style={styles.detailRow}>
                <Text style={styles.detailLabel}>Connectable:</Text>
                <Text style={styles.detailValue}>
                  {selectedDevice.isConnectable ? 'Yes' : 'No'}
                </Text>
              </View>
              
              {selectedDevice.serviceUUIDs && (
                <View style={styles.detailSection}>
                  <Text style={styles.detailLabel}>Services:</Text>
                  {selectedDevice.serviceUUIDs.map((uuid, index) => (
                    <Text key={index} style={styles.detailValueSmall}>
                      • {uuid}
                    </Text>
                  ))}
                </View>
              )}
            </ScrollView>
          )}
          
          <View style={styles.modalButtons}>
            <TouchableOpacity
              style={[styles.modalButton, styles.connectButton]}
              onPress={() => {
                setShowDetails(false);
                connectToDevice(selectedDevice);
              }}
            >
              <Text style={styles.modalButtonText}>Connect</Text>
            </TouchableOpacity>
            
            <TouchableOpacity
              style={[styles.modalButton, styles.closeButton]}
              onPress={() => setShowDetails(false)}
            >
              <Text style={styles.modalButtonText}>Close</Text>
            </TouchableOpacity>
          </View>
        </View>
      </View>
    </Modal>
  );

  return (
    <View style={styles.container}>
      <View style={styles.header}>
        <Text style={styles.title}>Thermal Printer Scanner</Text>
        
        <View style={styles.statusIndicator}>
          <View style={[
            styles.statusDot,
            { backgroundColor: connectedDevice ? '#4CAF50' : '#F44336' }
          ]} />
          <Text style={styles.statusText}>
            {connectedDevice ? 'CONNECTED' : 'NOT CONNECTED'}
          </Text>
        </View>
      </View>

      {connectedDevice && (
        <View style={styles.connectedDeviceContainer}>
          <Text style={styles.connectedDeviceText}>
            Connected to: {connectedDevice.name || 'Unknown Device'}
          </Text>
          <TouchableOpacity
            style={styles.disconnectButton}
            onPress={disconnectDevice}
          >
            <Text style={styles.disconnectButtonText}>Disconnect</Text>
          </TouchableOpacity>
        </View>
      )}

      <View style={styles.scanControls}>
        <TouchableOpacity
          style={[styles.scanButton, scanning && styles.scanningButton]}
          onPress={scanning ? stopScanning : startScanning}
          disabled={!permissionsGranted || connecting}
        >
          <Text style={styles.scanButtonText}>
            {scanning ? 'Stop Scanning' : 'Scan for Printers'}
          </Text>
          {scanning && <ActivityIndicator color="#FFF" style={styles.scanIndicator} />}
        </TouchableOpacity>
        
        {!permissionsGranted && (
          <TouchableOpacity
            style={styles.permissionButton}
            onPress={requestPermissions}
          >
            <Text style={styles.permissionButtonText}>Grant Permissions</Text>
          </TouchableOpacity>
        )}
      </View>

      <Text style={styles.devicesCount}>
        Found Devices: {devices.length}
      </Text>

      {scanning && devices.length === 0 && (
        <View style={styles.emptyState}>
          <ActivityIndicator size="large" color="#2196F3" />
          <Text style={styles.emptyStateText}>Scanning for printers...</Text>
          <Text style={styles.emptyStateSubtext}>
            Make sure your printer is turned on and in pairing mode
          </Text>
        </View>
      )}

      <FlatList
        data={devices}
        renderItem={renderDeviceItem}
        keyExtractor={item => item.id}
        style={styles.deviceList}
        contentContainerStyle={devices.length === 0 && styles.emptyList}
      />

      <DeviceDetailsModal />
    </View>
  );
};

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: '#f5f5f5',
    padding: 20,
  },
  header: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
    marginBottom: 20,
  },
  title: {
    fontSize: 24,
    fontWeight: 'bold',
    color: '#333',
  },
  statusIndicator: {
    flexDirection: 'row',
    alignItems: 'center',
  },
  statusDot: {
    width: 10,
    height: 10,
    borderRadius: 5,
    marginRight: 5,
  },
  statusText: {
    fontSize: 12,
    fontWeight: 'bold',
  },
  connectedDeviceContainer: {
    backgroundColor: '#E8F5E9',
    padding: 15,
    borderRadius: 10,
    marginBottom: 20,
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
  },
  connectedDeviceText: {
    fontSize: 14,
    color: '#2E7D32',
    fontWeight: '500',
  },
  disconnectButton: {
    backgroundColor: '#FF5252',
    paddingHorizontal: 15,
    paddingVertical: 8,
    borderRadius: 5,
  },
  disconnectButtonText: {
    color: 'white',
    fontSize: 12,
    fontWeight: 'bold',
  },
  scanControls: {
    marginBottom: 20,
  },
  scanButton: {
    backgroundColor: '#2196F3',
    padding: 15,
    borderRadius: 10,
    alignItems: 'center',
    flexDirection: 'row',
    justifyContent: 'center',
  },
  scanningButton: {
    backgroundColor: '#FF9800',
  },
  scanButtonText: {
    color: 'white',
    fontSize: 16,
    fontWeight: 'bold',
  },
  scanIndicator: {
    marginLeft: 10,
  },
  permissionButton: {
    backgroundColor: '#9C27B0',
    padding: 10,
    borderRadius: 5,
    marginTop: 10,
    alignItems: 'center',
  },
  permissionButtonText: {
    color: 'white',
    fontSize: 14,
  },
  devicesCount: {
    fontSize: 14,
    color: '#666',
    marginBottom: 10,
  },
  emptyState: {
    alignItems: 'center',
    justifyContent: 'center',
    padding: 40,
  },
  emptyStateText: {
    marginTop: 20,
    fontSize: 16,
    color: '#666',
  },
  emptyStateSubtext: {
    marginTop: 10,
    fontSize: 14,
    color: '#999',
    textAlign: 'center',
  },
  deviceList: {
    flex: 1,
  },
  emptyList: {
    flexGrow: 1,
    justifyContent: 'center',
  },
  deviceItem: {
    backgroundColor: 'white',
    padding: 15,
    borderRadius: 10,
    marginBottom: 10,
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
    shadowColor: '#000',
    shadowOffset: { width: 0, height: 2 },
    shadowOpacity: 0.1,
    shadowRadius: 4,
    elevation: 3,
  },
  deviceInfo: {
    flex: 1,
  },
  deviceName: {
    fontSize: 16,
    fontWeight: 'bold',
    color: '#333',
  },
  deviceId: {
    fontSize: 12,
    color: '#666',
    marginTop: 2,
  },
  deviceRssi: {
    fontSize: 12,
    color: '#2196F3',
    marginTop: 2,
  },
  connectButton: {
    backgroundColor: '#4CAF50',
    paddingHorizontal: 15,
    paddingVertical: 8,
    borderRadius: 5,
  },
  connectedButton: {
    backgroundColor: '#FF5252',
  },
  connectButtonText: {
    color: 'white',
    fontSize: 12,
    fontWeight: 'bold',
  },
  modalContainer: {
    flex: 1,
    backgroundColor: 'rgba(0, 0, 0, 0.5)',
    justifyContent: 'center',
    alignItems: 'center',
    padding: 20,
  },
  modalContent: {
    backgroundColor: 'white',
    borderRadius: 15,
    padding: 20,
    width: '90%',
    maxHeight: '80%',
  },
  modalTitle: {
    fontSize: 20,
    fontWeight: 'bold',
    marginBottom: 20,
    textAlign: 'center',
  },
  detailRow: {
    flexDirection: 'row',
    marginBottom: 10,
    borderBottomWidth: 1,
    borderBottomColor: '#f0f0f0',
    paddingBottom: 10,
  },
  detailLabel: {
    fontWeight: 'bold',
    width: 120,
    color: '#555',
  },
  detailValue: {
    flex: 1,
    color: '#333',
  },
  detailValueSmall: {
    fontSize: 12,
    color: '#666',
    marginLeft: 10,
    marginTop: 2,
  },
  detailSection: {
    marginBottom: 15,
  },
  modalButtons: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    marginTop: 20,
  },
  modalButton: {
    flex: 1,
    padding: 12,
    borderRadius: 8,
    alignItems: 'center',
    marginHorizontal: 5,
  },
  modalButtonText: {
    color: 'white',
    fontWeight: 'bold',
  },
});

export default DeviceScanner;