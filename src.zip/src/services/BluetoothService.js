import { BleManager } from 'react-native-ble-plx';
import { PermissionsAndroid, Platform } from 'react-native';
import { check, PERMISSIONS, request, RESULTS } from 'react-native-permissions';

class BluetoothService {
  constructor() {
    this.manager = new BleManager();
    this.connectedDevice = null;
    this.discoveredDevices = new Map(); // Map to store discovered devices
    this.isScanning = false;
    this.onDeviceFound = null; // Callback for when devices are found
    this.onDeviceConnected = null; // Callback for connection events
  }

  // ========== PERMISSION HANDLING ==========
  requestBluetoothPermissions = async () => {
    if (Platform.OS === 'android') {
      // For Android 12+
      if (Platform.Version >= 31) {
        const permissions = [
          PermissionsAndroid.PERMISSIONS.BLUETOOTH_SCAN,
          PermissionsAndroid.PERMISSIONS.BLUETOOTH_CONNECT,
          PermissionsAndroid.PERMISSIONS.ACCESS_FINE_LOCATION,
        ];
        
        const granted = await PermissionsAndroid.requestMultiple(permissions);
        
        const allGranted = Object.values(granted).every(
          result => result === PermissionsAndroid.RESULTS.GRANTED
        );
        
        return allGranted;
      } else {
        // For Android 11 and below
        const granted = await PermissionsAndroid.request(
          PermissionsAndroid.PERMISSIONS.ACCESS_FINE_LOCATION,
          {
            title: 'Location Permission',
            message: 'Bluetooth scanning requires location permission',
            buttonNeutral: 'Ask Me Later',
            buttonNegative: 'Cancel',
            buttonPositive: 'OK',
          }
        );
        return granted === PermissionsAndroid.RESULTS.GRANTED;
      }
    } else {
      // iOS permissions
      const result = await request(PERMISSIONS.IOS.BLUETOOTH_PERIPHERAL);
      return result === RESULTS.GRANTED;
    }
  };

  // ========== DEVICE SCANNING ==========
  startDeviceScan = (onDeviceFoundCallback) => {
    if (this.isScanning) {
      console.log('Already scanning for devices');
      return;
    }

    this.onDeviceFound = onDeviceFoundCallback;
    this.discoveredDevices.clear(); // Clear previous discoveries
    this.isScanning = true;

    console.log('Starting BLE device scan...');

    // Start scanning
    this.manager.startDeviceScan(null, null, (error, device) => {
      if (error) {
        console.error('Scan error:', error);
        this.stopDeviceScan();
        return;
      }

      // Filter for thermal printers (common identifiers)
      if (this.isLikelyPrinter(device)) {
        const deviceId = device.id;
        
        // Only add if not already discovered
        if (!this.discoveredDevices.has(deviceId)) {
          this.discoveredDevices.set(deviceId, device);
          
          // Format device info for UI
          const deviceInfo = {
            id: device.id,
            name: device.name || 'Unknown Device',
            localName: device.localName || '',
            rssi: device.rssi,
            manufacturerData: device.manufacturerData,
            serviceUUIDs: device.serviceUUIDs,
            isConnectable: device.isConnectable,
          };
          
          // Notify UI about discovered device
          if (this.onDeviceFound) {
            this.onDeviceFound(deviceInfo);
          }
        }
      }
    });

    // Auto-stop scanning after 10 seconds
    setTimeout(() => {
      this.stopDeviceScan();
      console.log('Auto-stopped scanning after 10 seconds');
    }, 10000);
  };

  stopDeviceScan = () => {
    if (this.isScanning) {
      this.manager.stopDeviceScan();
      this.isScanning = false;
      console.log('Stopped device scanning');
    }
  };

  // Helper to identify potential printers
  isLikelyPrinter = (device) => {
    // Check by name patterns (common thermal printer names)
    const printerNamePatterns = [
      'printer', 'PRINTER', 'Printer',
      'POS', 'pos',
      'TP', 'tp', // Thermal Printer
      'SP', 'sp', // Serial Printer
      'BT-Print', 'BTPrint',
      'EPSON', 'epson',
      'Zebra', 'zebra',
      'Star', 'star',
      'Citizen', 'citizen',
    ];

    const deviceName = device.name || device.localName || '';
    
    // Check if name contains any printer pattern
    if (deviceName) {
      return printerNamePatterns.some(pattern => 
        deviceName.toLowerCase().includes(pattern.toLowerCase())
      );
    }

    // Alternatively, check for service UUIDs common to printers
    if (device.serviceUUIDs && device.serviceUUIDs.length > 0) {
      // Common printer service UUIDs
      const printerServiceUUIDs = [
        '00001101-0000-1000-8000-00805F9B34FB', // Serial Port Profile (SPP)
        'E7810A71-73AE-499D-8C15-DAA818301B8E', // ESC/POS printers
      ];
      
      return device.serviceUUIDs.some(uuid => 
        printerServiceUUIDs.includes(uuid.toUpperCase())
      );
    }

    return false;
  };

  // ========== DEVICE CONNECTION ==========
  connectToDevice = async (deviceId, onConnectionCallback) => {
    if (this.connectedDevice) {
      console.log('Already connected to a device. Disconnecting first...');
      await this.disconnectDevice();
    }

    this.onDeviceConnected = onConnectionCallback;

    try {
      console.log(`Connecting to device: ${deviceId}`);
      
      // Connect to the device
      const device = await this.manager.connectToDevice(deviceId, {
        requestMTU: 512, // Request maximum transmission unit for faster data
        connectionTimeout: 10000, // 10 second timeout
      });

      // Discover services and characteristics
      await device.discoverAllServicesAndCharacteristics();
      
      this.connectedDevice = device;
      console.log(`Successfully connected to: ${device.name || deviceId}`);

      // Set up connection monitoring
      this.monitorDeviceConnection(device);

      // Notify about successful connection
      if (this.onDeviceConnected) {
        this.onDeviceConnected({
          success: true,
          device: {
            id: device.id,
            name: device.name || 'Unknown Device',
            mtu: device.mtu,
          },
          error: null,
        });
      }

      return { success: true, device };

    } catch (error) {
      console.error('Connection failed:', error);
      
      if (this.onDeviceConnected) {
        this.onDeviceConnected({
          success: false,
          device: null,
          error: error.message,
        });
      }
      
      return { success: false, error: error.message };
    }
  };

  // Monitor connection state
  monitorDeviceConnection = (device) => {
    device.onDisconnected((error, device) => {
      console.log(`Device disconnected: ${device.id}`, error || '');
      this.connectedDevice = null;
      
      // Attempt reconnection if it was an unexpected disconnect
      if (!error) {
        console.log('Attempting to reconnect...');
        setTimeout(() => {
          if (!this.connectedDevice) {
            this.connectToDevice(device.id, this.onDeviceConnected);
          }
        }, 5000);
      }
    });
  };

  // ========== DISCONNECTION ==========
  disconnectDevice = async () => {
    if (this.connectedDevice) {
      try {
        await this.connectedDevice.cancelConnection();
        console.log('Disconnected from device');
        this.connectedDevice = null;
        return { success: true };
      } catch (error) {
        console.error('Disconnection error:', error);
        return { success: false, error: error.message };
      }
    }
    return { success: true, message: 'No device connected' };
  };

  // ========== GETTERS ==========
  getConnectedDevice = () => this.connectedDevice;
  getDiscoveredDevices = () => Array.from(this.discoveredDevices.values());
  isDeviceConnected = () => this.connectedDevice !== null;
}

// Export as singleton
export default new BluetoothService();