import io from 'socket.io-client';
import PrinterService from './PrinterService';
import AsyncStorage from '@react-native-async-storage/async-storage';
import { AppState } from 'react-native';

class SocketService {
  constructor() {
    this.socket = null;
    this.SERVER_URL = 'YOUR_SERVER_URL'; // Replace with your server URL
    this.isConnected = false;
    this.reconnectAttempts = 0;
    this.maxReconnectAttempts = 10;
  }

  initializeSocket = async () => {
    try {
      const token = await AsyncStorage.getItem('auth_token');
      
      this.socket = io(this.SERVER_URL, {
        transports: ['websocket'],
        reconnection: true,
        reconnectionAttempts: this.maxReconnectAttempts,
        reconnectionDelay: 1000,
        query: { token },
      });

      this.setupEventListeners();
      this.setupAppStateListener();
      
    } catch (error) {
      console.error('Socket initialization failed:', error);
    }
  };

  setupEventListeners = () => {
    this.socket.on('connect', () => {
      console.log('Socket connected');
      this.isConnected = true;
      this.reconnectAttempts = 0;
      
      // Register device with server
      this.registerDevice();
    });

    this.socket.on('print_job', async (data) => {
      console.log('Received print job:', data);
      
      // Add to print queue
      await PrinterService.printReceipt(data);
      
      // Acknowledge receipt
      this.socket.emit('print_acknowledged', {
        jobId: data.jobId,
        status: 'queued',
        timestamp: new Date().toISOString()
      });
    });

    this.socket.on('disconnect', () => {
      console.log('Socket disconnected');
      this.isConnected = false;
      this.attemptReconnection();
    });

    this.socket.on('error', (error) => {
      console.error('Socket error:', error);
    });
  };

  registerDevice = () => {
    const deviceInfo = {
      deviceId: 'UNIQUE_DEVICE_ID', // Generate or get device ID
      type: 'printer',
      status: 'online',
      capabilities: ['thermal_printing']
    };
    
    this.socket.emit('register_device', deviceInfo);
  };

  attemptReconnection = () => {
    if (this.reconnectAttempts < this.maxReconnectAttempts) {
      this.reconnectAttempts++;
      setTimeout(() => {
        this.socket.connect();
      }, 5000 * this.reconnectAttempts); // Exponential backoff
    }
  };

  setupAppStateListener = () => {
    AppState.addEventListener('change', (nextAppState) => {
      if (nextAppState === 'background') {
        // Keep connection alive in background
        this.socket.io.opts.transports = ['polling', 'websocket'];
      } else if (nextAppState === 'active') {
        // Restore preferred transport
        this.socket.io.opts.transports = ['websocket'];
      }
    });
  };

  disconnect = () => {
    if (this.socket) {
      this.socket.disconnect();
    }
  };
}

export default new SocketService();