import { BleManager } from 'react-native-ble-plx';
import EscPosPrinter from 'react-native-esc-pos-printer';
import AsyncStorage from '@react-native-async-storage/async-storage';
// import BackgroundTask from 'react-native-background-task';

class PrinterService {
  constructor() {
    this.manager = new BleManager();
    this.connectedDevice = null;
    this.isPrinting = false;
    this.printQueue = [];
    this.reconnectInterval = null;
    this.STORAGE_KEY = 'PRINTER_DEVICE_ID';
  }

  // Initialize Bluetooth
  initializeBluetooth = async () => {
    try {
      await this.manager.enable();
      this.startDeviceScan();
    //   this.setupBackgroundTask();
      return true;
    } catch (error) {
      console.error('Bluetooth initialization failed:', error);
      return false;
    }
  };

  // Scan for printers
  startDeviceScan = () => {
    this.manager.startDeviceScan(null, null, (error, device) => {
      if (error) {
        console.error('Scan error:', error);
        return;
      }

      // Filter for thermal printers (common names)
      if (device.name && (
        device.name.includes('Printer') ||
        device.name.includes('POS') ||
        device.name.includes('Thermal')
      )) {
        this.connectToDevice(device);
      }
    });
  };

  // Connect to device
  connectToDevice = async (device) => {
    try {
      console.log('Connecting to:', device.name);
      
      const connectedDevice = await device.connect();
      const discoveredDevice = await connectedDevice.discoverAllServicesAndCharacteristics();
      
      await AsyncStorage.setItem(this.STORAGE_KEY, device.id);
      this.connectedDevice = discoveredDevice;
      
      console.log('Connected successfully');
      this.checkPrintQueue();
      
      // Setup auto-reconnection
      this.setupReconnection(device.id);
      
    } catch (error) {
      console.error('Connection failed:', error);
    }
  };

  // Setup auto-reconnection
  setupReconnection = (deviceId) => {
    if (this.reconnectInterval) {
      clearInterval(this.reconnectInterval);
    }

    this.reconnectInterval = setInterval(async () => {
      if (!this.connectedDevice || !this.connectedDevice.isConnected) {
        const storedDeviceId = await AsyncStorage.getItem(this.STORAGE_KEY);
        if (storedDeviceId) {
          const devices = await this.manager.devices([storedDeviceId]);
          if (devices && devices.length > 0) {
            this.connectToDevice(devices[0]);
          }
        }
      }
    }, 30000); // Check every 30 seconds
  };

  // Print function
  printReceipt = async (data) => {
    if (!this.connectedDevice) {
      this.printQueue.push(data);
      console.log('Device not connected, added to queue');
      return false;
    }

    if (this.isPrinting) {
      this.printQueue.push(data);
      console.log('Printer busy, added to queue');
      return false;
    }

    this.isPrinting = true;
    
    try {
      const commands = await EscPosPrinter.printingCommands({
        encoding: 'GBK',
        commands: this.generatePrintCommands(data)
      });

      await EscPosPrinter.print(this.connectedDevice.id, commands);
      console.log('Print successful');
      
      this.isPrinting = false;
      this.checkPrintQueue();
      return true;
      
    } catch (error) {
      console.error('Print failed:', error);
      this.isPrinting = false;
      return false;
    }
  };

  // Generate ESC/POS commands
  generatePrintCommands = (data) => {
    const commands = [];
    
    commands.push({ command: 'ALIGN', value: 'CENTER' });
    commands.push({ command: 'TEXT', value: '=== RECEIPT ===\n' });
    commands.push({ command: 'LINE_FEED' });
    
    commands.push({ command: 'ALIGN', value: 'LEFT' });
    commands.push({ command: 'TEXT', value: `Date: ${new Date().toLocaleString()}\n` });
    commands.push({ command: 'LINE_FEED' });
    
    commands.push({ command: 'TEXT', value: `${data.content}\n` });
    commands.push({ command: 'LINE_FEED', value: 2 });
    
    commands.push({ command: 'ALIGN', value: 'CENTER' });
    commands.push({ command: 'TEXT', value: 'Thank you!\n' });
    commands.push({ command: 'CUT', value: 'FULL' });
    
    return commands;
  };

  // Process print queue
  checkPrintQueue = () => {
    if (this.printQueue.length > 0 && !this.isPrinting && this.connectedDevice) {
      const nextJob = this.printQueue.shift();
      this.printReceipt(nextJob);
    }
  };

  // Background task setup
  setupBackgroundTask = () => {
    BackgroundTask.define(async () => {
      await this.checkPrintQueue();
      BackgroundTask.finish();
    });
  };

  // Start background service
  startBackgroundService = () => {
    BackgroundTask.schedule({
      period: 900, // 15 minutes minimum
    });
  };

  // Disconnect printer
  disconnect = async () => {
    if (this.connectedDevice) {
      await this.connectedDevice.cancelConnection();
    }
    if (this.reconnectInterval) {
      clearInterval(this.reconnectInterval);
    }
  };
}

export default new PrinterService();